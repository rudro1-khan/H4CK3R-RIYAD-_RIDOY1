<?php
echo "Subdomain provisioning system is under development. This will auto-generate subdomains like user.yoursite.com.";
?>