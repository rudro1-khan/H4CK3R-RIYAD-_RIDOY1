
<!DOCTYPE html>
<html>
<head>
  <title>PDF Downloader</title>
  <style>
    body { background-color: black; color: lime; font-family: monospace; text-align: center; padding-top: 100px; }
    input, button { padding: 10px; font-size: 16px; }
  </style>
</head>
<body>
  <h1>📘 PDF Downloader</h1>
  <input type="text" id="search" placeholder="Enter topic (e.g. hacking)" />
  <button onclick="download()">Search & Download</button>
  <p id="result"></p>
  <script>
    function download() {
      const topic = document.getElementById('search').value;
      if (!topic) return alert("Enter a topic.");
      document.getElementById('result').innerHTML = `Download <a href="https://example.com/${topic}.pdf" target="_blank">${topic}.pdf</a>`;
    }
  </script>
</body>
</html>
