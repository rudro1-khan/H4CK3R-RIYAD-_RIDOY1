<?php
echo "FTP user creation system is under development. Each user will get FTP access credentials.";
?>