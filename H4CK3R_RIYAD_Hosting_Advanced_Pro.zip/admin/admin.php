<?php echo 'Admin Panel: Only for authorized access'; ?>
<hr>
<h3>User List:</h3>
<ul>
<?php
$users = json_decode(file_get_contents('../users.json'), true);
foreach ($users as $u) {
    echo "<li>" . htmlspecialchars($u['email']) . " (" . htmlspecialchars($u['role']) . ")</li>";
}
?>
</ul>

<h3>Storage Summary:</h3>
<?php
$uploadDir = '../uploads/';
$totalSize = 0;
if (is_dir($uploadDir)) {
    $files = scandir($uploadDir);
    foreach ($files as $file) {
        if ($file != '.' && $file != '..') {
            $totalSize += filesize($uploadDir . $file);
        }
    }
    echo "Total Uploaded Size: " . round($totalSize / (1024 * 1024), 2) . " MB";
}
?>
