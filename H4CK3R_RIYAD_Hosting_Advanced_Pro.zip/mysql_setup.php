<?php
echo "MySQL auto-database provisioning will allow each user to have a separate DB.";
?>