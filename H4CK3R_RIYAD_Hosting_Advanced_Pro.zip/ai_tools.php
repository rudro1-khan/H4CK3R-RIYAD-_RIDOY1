
<!DOCTYPE html>
<html>
<head>
    <title>AI Tools</title>
</head>
<body>
    <h2>AI Tool Demo</h2>
    <form method="post">
        <label>Ask AI:</label><br>
        <input type="text" name="query" required>
        <button type="submit">Submit</button>
    </form>
    <div>
        <h3>Response:</h3>
        <p>
        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $query = htmlspecialchars($_POST['query']);
            echo "You asked: " . $query . "<br>";
            echo "AI says: This is a demo response. Connect real API here.";
        }
        ?>
        </p>
    </div>
</body>
</html>
