
<?php
if (isset($_GET['url'])) {
    $url = urldecode($_GET['url']);
    include 'phpqrcode/qrlib.php'; // Ensure phpqrcode library is included
    QRcode::png($url);
}
?>
