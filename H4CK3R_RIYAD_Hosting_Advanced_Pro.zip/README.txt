
H4CK3R RIYAD Free Hosting Service Setup Guide

1. Upload all files to Replit or a PHP-supported host (e.g., InfinityFree).
2. Access index.html to visit the site.
3. Use 'admin/admin.php' for admin access.
4. Admin Email: admin@riyad.com
   Password: 123456

Developed by: H4CK3R RIYAD
