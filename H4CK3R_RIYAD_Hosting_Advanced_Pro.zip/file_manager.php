
<?php
$uploadDir = 'uploads/';
$expiryHours = 105120; // 2 days
$totalSize = 0;

if (is_dir($uploadDir)) {
    $files = scandir($uploadDir);
    foreach ($files as $file) {
        if ($file != '.' && $file != '..') {
            $filePath = $uploadDir . $file;
            $fileAge = (time() - filemtime($filePath)) / 3600;

            if ($fileAge > $expiryHours) {
                unlink($filePath); // delete expired file
            } else {
                $totalSize += filesize($filePath);
            }
        }
    }
    echo "Used Storage: " . round($totalSize / (1024 * 1024), 2) . " MB<br>";
}
?>
<?php echo 'Simple File Manager interface here'; ?>